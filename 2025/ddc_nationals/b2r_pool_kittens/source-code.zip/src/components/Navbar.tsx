'use client'

import Link from 'next/link'

export default function Navbar() {
        return (
                <nav className="flex justify-center items-center gap-10 pt-10 font-[family-name:var(--font-geist-sans)]">
                        <Link href='/'>Home</Link>
                        <Link href='/videos'>Videos</Link>
                </nav>
        );
};

