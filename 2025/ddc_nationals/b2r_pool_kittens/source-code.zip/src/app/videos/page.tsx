import Image from "next/image";
import Link from "next/link";

export default function Videos() {
  return (
    <div className="grid grid-rows-[0px_1fr_20px] items-center justify-items-center min-h-screen pr-80 pl-80 pb-20 sm:p-20 gap-16 font-[family-name:var(--font-geist-sans)]">
        <div className="grid items-center justify-items-center">
        <Link className="text-lime-500 font-bold" href="/source-code.zip">&gt;&gt; Click me to get started! &lt;&lt;</Link>
        <div>We are Open Source! Participate now!</div>
        </div>
      <main className="grid grid-cols-3 grid-rows-4 gap-8 row-start-2 items-center sm:items-start">
      <div>Under development! We need you! Get started now! Checkout our awesome history! We use GIT!</div>
        <Image 
            src="/"
            width={500}
            height={500}
            alt=""
            className="w-full h-full object-cover"
        />
        <Image 
            src="/"
            width={500}
            height={500}
            alt=""
            className="w-full h-full object-cover"
        />
        <Image 
            src="/"
            width={500}
            height={500}
            alt=""
            className="w-full h-full object-cover"
        />
        <Image 
            src="/"
            width={500}
            height={500}
            alt=""
            className="w-full h-full object-cover"
        />
        <Image 
            src="/"
            width={500}
            height={500}
            alt=""
            className="w-full h-full object-cover"
        />
        <Image 
            src="/"
            width={500}
            height={500}
            alt=""
            className="w-full h-full object-cover"
        />
        <Image 
            src="/"
            width={500}
            height={500}
            alt=""
            className="w-full h-full object-cover"
        />
        <Image 
            src="/"
            width={500}
            height={500}
            alt=""
            className="w-full h-full object-cover"
        />
      </main>
      <footer className="row-start-3 flex gap-6 flex-wrap items-center justify-center">
        <div>@2025 OpenPKPProviders</div>
        <div>Pool Kittens Providers</div>
        <div>Open Source</div>
      </footer>
    </div>
  );
}
