import Image from 'next/image'

export default function Home() {
  return (
    <div className="grid grid-rows-[0px_1fr_20px] items-center justify-items-center min-h-screen pr-80 pl-80 pb-20 sm:p-20 gap-16 font-[family-name:var(--font-geist-sans)]">
      <main className="grid grid-cols-3 grid-rows-4 gap-8 row-start-2 items-center sm:items-start">
        <Image 
            src="/polkit-swim.jpg"
            width={500}
            height={500}
            alt="Cute pool kitten swimming"
            className="w-full h-full object-cover"
        />
        <Image 
            src="/polkit-shy.jpg"
            width={500}
            height={500}
            alt="Shy pool kitten"
            className="w-full h-full object-cover"
        />
        <Image 
            src="/polkit-sad.jpg"
            width={500}
            height={500}
            alt="Sad pool kitten"
            className="w-full h-full object-cover"
        />
        <Image 
            src="/polkit-cool.jpg"
            width={500}
            height={500}
            alt="Cool pool kitten"
            className="w-full h-full object-cover"
        />
        <Image 
            src="/polkit-sporty.jpg"
            width={500}
            height={500}
            alt="Sporty pool kitten"
            className="w-full h-full object-cover"
        />
        <Image 
            src="/polkit-relaxed.jpg"
            width={500}
            height={500}
            alt="Relaxed pool kitten"
            className="w-full h-full object-cover"
        />
        <Image 
            src="/polkit-fake.jpg"
            width={500}
            height={500}
            alt="Fake pool kitten"
            className="w-full h-full object-cover"
        />
        <Image 
            src="/polkit-sunbathing.jpg"
            width={500}
            height={500}
            alt="Sunbathing pool kitten"
            className="w-full h-full object-cover"
        />
        <Image 
            src="/polkit-playing.jpg"
            width={500}
            height={500}
            alt="Playing pool kitten"
            className="w-full h-full object-cover"
        />
      </main>
      <footer className="row-start-3 flex gap-6 flex-wrap items-center justify-center">
        <div>@2025 OpenPKPProviders</div>
        <div>Pool Kittens Providers</div>
        <div>Open Source</div>
      </footer>
    </div>
  );
}

