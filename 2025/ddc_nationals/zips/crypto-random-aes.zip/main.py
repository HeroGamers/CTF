from Crypto.Cipher import AES
import random


with open("flag.txt", "rb") as f:
    flag = f.read()

# Sample a random 128 bit key by selecting an integer between 0 and 2^128, then converting to bytes
def genkey():
    key_int = random.randrange(0,2^128)
    key_bytes = key_int.to_bytes(16,'little')
    return key_bytes

# Encrypt with AES CTR mode
def encrypt_flag(flag, key):
    aes = AES.new(key, AES.MODE_CTR)
    ct = aes.encrypt(flag)
    return aes.nonce, ct

key = genkey()
nonce, ct = encrypt_flag(flag, key)

with open("output.txt", "w") as f:
    f.write(f'iv = {nonce.hex()}\n')
    f.write(f'ct = {ct.hex()}\n')