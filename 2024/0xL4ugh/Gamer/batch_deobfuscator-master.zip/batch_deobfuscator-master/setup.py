from distutils.core import setup

setup(name='batch_deobfuscator',
      version='1.0',
      description='Transforms Batchfile Nightmares Into Blue Team Dream Warriors',
      author='@DissectMalware',
      url='https://github.com/DissectMalware/batch_deobfuscator/',
      packages=['batch_deobfuscator'],
     )
